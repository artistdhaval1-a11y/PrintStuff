import React from 'react';

interface LogoProps {
  className?: string;
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = 'h-9', showSubtitle = true }) => {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Brand Icon with vibrant splash palette reminiscent of PrintStuff identity */}
      <div className="relative w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-700/80 flex items-center justify-center shadow-inner overflow-hidden shrink-0">
        <svg viewBox="0 0 40 40" fill="none" className="w-6 h-6">
          <path d="M12 8C8 8 6 12 6 16C6 24 14 28 15 32C16 28 24 24 24 16C24 12 22 8 18 8C14 8 12 8 12 8Z" fill="#F43F5E" />
          <path d="M10 14C8 16 8 22 12 24C15 26 15 30 14 34C16 30 19 26 19 22C19 18 16 15 13 14Z" fill="#06B6D4" />
          <path d="M14 18C12 18 11 21 11 23C11 27 15 29 15 31C15 29 18 27 18 23C18 21 16 18 14 18Z" fill="#FACC15" />
          <text x="18" y="27" fontFamily="'Outfit', sans-serif" fontWeight="900" fontSize="16" fill="#FFFFFF" textAnchor="middle">PS</text>
        </svg>
      </div>

      <div className="flex flex-col leading-none">
        <span className="font-display font-extrabold text-lg tracking-wider text-white uppercase">
          Print<span className="text-emerald-400">Stuff</span>
        </span>
        {showSubtitle && (
          <span className="text-[9px] font-mono tracking-widest text-neutral-400 uppercase">
            Custom Apparel Co.
          </span>
        )}
      </div>
    </div>
  );
};
