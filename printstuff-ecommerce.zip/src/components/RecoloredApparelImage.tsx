import React, { useEffect, useState } from 'react';
import { ProductColor } from '../types';
import { PRODUCTS } from '../data/products';

interface RecoloredApparelImageProps {
  src: string;
  productId: string;
  view: 'front' | 'back';
  color: ProductColor;
  className?: string;
  alt: string;
}

// In-memory cache for processed canvas data URLs: key = `${src}_${color.hex}`
const imageCache = new Map<string, string>();

interface GarmentBounds {
  yMin: number; // percentage 0-1
  yMax: number;
  xMin: number;
  xMax: number;
  isCap?: boolean;
}

const GARMENT_BOUNDS: Record<string, Record<'front' | 'back', GarmentBounds>> = {
  'crew-neck-tshirt': {
    front: { yMin: 0.12, yMax: 0.88, xMin: 0.08, xMax: 0.92 },
    back: { yMin: 0.12, yMax: 0.88, xMin: 0.08, xMax: 0.92 }
  },
  'zipper-hoodie': {
    front: { yMin: 0.10, yMax: 0.90, xMin: 0.10, xMax: 0.90 },
    back: { yMin: 0.10, yMax: 0.90, xMin: 0.10, xMax: 0.90 }
  },
  'regular-hoodie': {
    front: { yMin: 0.10, yMax: 0.90, xMin: 0.10, xMax: 0.90 },
    back: { yMin: 0.10, yMax: 0.90, xMin: 0.10, xMax: 0.90 }
  },
  'classic-polo': {
    front: { yMin: 0.08, yMax: 0.92, xMin: 0.08, xMax: 0.92 },
    back: { yMin: 0.08, yMax: 0.92, xMin: 0.08, xMax: 0.92 }
  },
  'premium-polo': {
    front: { yMin: 0.08, yMax: 0.92, xMin: 0.08, xMax: 0.92 },
    back: { yMin: 0.08, yMax: 0.92, xMin: 0.08, xMax: 0.92 }
  },
  'custom-cap': {
    front: { yMin: 0.10, yMax: 0.65, xMin: 0.06, xMax: 0.94, isCap: true },
    back: { yMin: 0.10, yMax: 0.65, xMin: 0.06, xMax: 0.94, isCap: true }
  }
};

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c.split('').map((char) => char + char).join('');
  }
  const num = parseInt(c, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

export const RecoloredApparelImage: React.FC<RecoloredApparelImageProps> = ({
  src,
  productId,
  view,
  color,
  className = '',
  alt
}) => {
  const [renderedSrc, setRenderedSrc] = useState<string>(src);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const isOriginalBlack =
    color.isOriginalPhotoColor ||
    color.hex.toLowerCase() === '#111111' ||
    color.name.toLowerCase().includes('black');

  useEffect(() => {
    // Priority 1: Check if an exact matching real photograph exists for this color & view
    const product = PRODUCTS.find((p) => p.id === productId);
    const colorPhoto = product?.colorImages?.[color.name]?.[view];
    if (colorPhoto) {
      setRenderedSrc(colorPhoto);
      return;
    }

    // Priority 2: Original Black uses master studio photo directly
    if (isOriginalBlack) {
      setRenderedSrc(src);
      return;
    }

    // Priority 3: Check memory cache
    const cacheKey = `${src}_${color.hex}_${productId}_${view}`;
    if (imageCache.has(cacheKey)) {
      setRenderedSrc(imageCache.get(cacheKey)!);
      return;
    }

    // Priority 4: Clean ghost mannequin garment recoloring
    setIsProcessing(true);
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      const canvas = document.createElement('canvas');
      const w = img.naturalWidth || 896;
      const h = img.naturalHeight || 1200;
      canvas.width = w;
      canvas.height = h;

      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) {
        setRenderedSrc(src);
        setIsProcessing(false);
        return;
      }

      // Draw original image
      ctx.drawImage(img, 0, 0, w, h);
      const imgData = ctx.getImageData(0, 0, w, h);
      const data = imgData.data;

      const bounds = GARMENT_BOUNDS[productId]?.[view] || {
        yMin: 0.10,
        yMax: 0.90,
        xMin: 0.08,
        xMax: 0.92
      };

      const startY = Math.floor(bounds.yMin * h);
      const endY = Math.ceil(bounds.yMax * h);
      const startX = Math.floor(bounds.xMin * w);
      const endX = Math.ceil(bounds.xMax * w);

      const target = hexToRgb(color.hex);
      const isTargetWhite = target.r > 230 && target.g > 230 && target.b > 230;

      for (let y = startY; y < endY; y++) {
        for (let x = startX; x < endX; x++) {
          const idx = (y * w + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];

          // Compute perceived luminance
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;

          // Ghost mannequin images have neutral light background (lum > 210)
          // The dark garment fabric has lum < 75
          if (lum < 75) {
            // Normalize fabric texture luminance (natural range: 6 to 65)
            const lnorm = Math.max(0, Math.min(1, (lum - 6) / 58));

            let nr: number;
            let ng: number;
            let nb: number;

            if (isTargetWhite) {
              // Natural white fabric with shadow folds preserved
              const base = 185 + 68 * lnorm;
              nr = Math.min(255, Math.round(base));
              ng = Math.min(255, Math.round(base));
              nb = Math.min(255, Math.round(base + 1));
            } else {
              // Modulate target color preserving deep fabric folds, shadows, and highlights
              const shadowFactor = 0.44 + 0.88 * lnorm;
              const highlightSheen = Math.max(0, (lnorm - 0.74) * 65);

              nr = Math.min(255, Math.max(0, Math.round(target.r * shadowFactor + highlightSheen)));
              ng = Math.min(255, Math.max(0, Math.round(target.g * shadowFactor + highlightSheen)));
              nb = Math.min(255, Math.max(0, Math.round(target.b * shadowFactor + highlightSheen)));
            }

            data[idx] = nr;
            data[idx + 1] = ng;
            data[idx + 2] = nb;
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);
      const recoloredUrl = canvas.toDataURL('image/jpeg', 0.92);
      imageCache.set(cacheKey, recoloredUrl);
      setRenderedSrc(recoloredUrl);
      setIsProcessing(false);
    };

    img.onerror = () => {
      setRenderedSrc(src);
      setIsProcessing(false);
    };

    img.src = src;
  }, [src, color.hex, color.name, productId, view, isOriginalBlack]);

  return (
    <img
      src={renderedSrc}
      alt={alt}
      className={`${className} transition-opacity duration-200 ${isProcessing ? 'opacity-90' : 'opacity-100'}`}
      referrerPolicy="no-referrer"
    />
  );
};
