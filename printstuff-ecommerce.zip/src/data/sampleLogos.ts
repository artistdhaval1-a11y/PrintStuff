export interface SampleLogo {
  id: string;
  name: string;
  dataUrl: string;
  defaultWidth: number;
}

// Crisp vector SVG sample artwork for testing customizer
export const SAMPLE_LOGOS: SampleLogo[] = [
  {
    id: 'printstuff-crest',
    name: 'PrintStuff Brand Crest',
    defaultWidth: 42,
    dataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 120" fill="none">
        <path d="M45 20C30 20 15 32 15 50C15 75 40 85 45 105C50 85 75 75 75 50C75 32 60 20 45 20Z" fill="#F43F5E"/>
        <path d="M35 30C25 35 25 55 35 60C45 65 45 85 40 95C45 85 55 75 55 60C55 45 45 35 35 30Z" fill="#06B6D4"/>
        <path d="M45 40C40 40 35 48 35 55C35 68 45 72 45 80C45 72 55 68 55 55C55 48 50 40 45 40Z" fill="#FACC15"/>
        <text x="95" y="65" font-family="'Outfit', -apple-system, sans-serif" font-weight="900" font-size="38" fill="#FFFFFF" letter-spacing="1">PRINTSTUFF</text>
        <text x="96" y="90" font-family="'Plus Jakarta Sans', sans-serif" font-weight="600" font-size="14" fill="#06B6D4" letter-spacing="4">CUSTOM APPAREL</text>
      </svg>
    `)}`
  },
  {
    id: 'minimal-monogram',
    name: 'Urban Monogram',
    defaultWidth: 32,
    dataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" fill="none">
        <circle cx="100" cy="100" r="88" stroke="#FFFFFF" stroke-width="6"/>
        <circle cx="100" cy="100" r="76" stroke="#06B6D4" stroke-width="2" stroke-dasharray="8 6"/>
        <path d="M60 140V60H95C115 60 130 72 130 90C130 108 115 120 95 120H80V140H60ZM80 102H94C103 102 110 97 110 90C110 83 103 78 94 78H80V102Z" fill="#FFFFFF"/>
        <path d="M125 95H145V140H125V95Z" fill="#10B981"/>
      </svg>
    `)}`
  },
  {
    id: 'athletics-badge',
    name: 'Athletic Squad Crest',
    defaultWidth: 50,
    dataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 140" fill="none">
        <rect x="10" y="10" width="260" height="120" rx="16" fill="#18181B" stroke="#F59E0B" stroke-width="4"/>
        <text x="140" y="58" font-family="'Outfit', sans-serif" font-weight="800" font-size="34" fill="#F59E0B" text-anchor="middle" letter-spacing="2">APEX DIVISION</text>
        <line x1="30" y1="72" x2="250" y2="72" stroke="#3F3F46" stroke-width="2"/>
        <text x="140" y="98" font-family="'JetBrains Mono', monospace" font-weight="600" font-size="16" fill="#E4E4E7" text-anchor="middle" letter-spacing="4">HEAVYWEIGHT ATHLETICS</text>
      </svg>
    `)}`
  },
  {
    id: 'startup-badge',
    name: 'Tech Founder Emblem',
    defaultWidth: 35,
    dataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" fill="none">
        <polygon points="100,20 175,65 175,145 100,190 25,145 25,65" stroke="#38BDF8" stroke-width="6" fill="#09090B"/>
        <path d="M70 130L100 70L130 130" stroke="#FFFFFF" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="100" cy="110" r="10" fill="#38BDF8"/>
      </svg>
    `)}`
  }
];
