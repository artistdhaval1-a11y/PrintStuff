import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express, { type Request, type Response } from 'express';
import {
  CUSTOM_TEE_PRINT_TIERS,
  SHOPIFY_PRODUCTS,
  type CustomPrintTierKey,
} from './src/data/shopifyCatalog.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const FREE_SHIPPING_THRESHOLD = 1999;
const FLAT_SHIPPING_INR = 99;
const STORE_WHATSAPP_NUMBER = '917405652991';

interface OrderItemInput {
  productId: string;
  size: string;
  color?: string;
  frontPrint?: CustomPrintTierKey;
  backPrint?: CustomPrintTierKey;
  quantity: number;
}

interface VerifiedOrderLine {
  productId: string;
  title: string;
  size: string;
  color?: string;
  printSummary?: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

interface StoredOrder {
  orderId: string;
  createdAt: string;
  paymentMethod: 'razorpay' | 'cod';
  paymentStatus: 'paid' | 'preview_verified' | 'cod_confirmed';
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  customerName: string;
  customerPhoneE164: string;
  notifyChannel: 'whatsapp' | 'sms';
  addressLine: string;
  items: VerifiedOrderLine[];
  subtotalInr: number;
  shippingInr: number;
  grandTotalInr: number;
}

// Track pending Razorpay order amounts & completed orders in server memory
const pendingRazorpayOrders = new Map<string, { grandTotalInr: number; createdAt: number }>();
const completedOrders = new Map<string, StoredOrder>();

function normalizeIndianPhoneE164(raw: string): string {
  const digits = String(raw || '').replace(/\D/g, '');
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length >= 10 && digits.length <= 15) return `+${digits}`;
  return '';
}

function formatINR(amount: number): string {
  return `₹${amount.toLocaleString('en-IN')}`;
}

function computeCanonicalOrder(rawItems: unknown): {
  lines: VerifiedOrderLine[];
  subtotalInr: number;
  shippingInr: number;
  grandTotalInr: number;
} | null {
  if (!Array.isArray(rawItems) || rawItems.length === 0 || rawItems.length > 50) {
    return null;
  }

  const lines: VerifiedOrderLine[] = [];
  let subtotalInr = 0;

  for (const entry of rawItems) {
    if (!entry || typeof entry !== 'object') return null;
    const item = entry as Partial<OrderItemInput>;
    const product = SHOPIFY_PRODUCTS.find((p) => p.id === String(item.productId || ''));
    if (!product) return null;

    const qty = Number(item.quantity);
    if (!Number.isInteger(qty) || qty < 1 || qty > 100) return null;

    const size = String(item.size || '').trim().slice(0, 24) || 'M';
    let unitPrice = product.minPrice;
    let printSummary: string | undefined;

    if (product.isCustomTee) {
      const fTier = CUSTOM_TEE_PRINT_TIERS.find((t) => t.key === item.frontPrint) || CUSTOM_TEE_PRINT_TIERS[0];
      const bTier = CUSTOM_TEE_PRINT_TIERS.find((t) => t.key === item.backPrint) || CUSTOM_TEE_PRINT_TIERS[0];
      unitPrice = 199 + fTier.charge + bTier.charge;
      printSummary = `Front: ${fTier.key} | Back: ${bTier.key}`;
    } else if (product.variants.length > 0) {
      const matched = product.variants.find(
        (v) => v.option1.toLowerCase() === size.toLowerCase()
      );
      if (matched) {
        unitPrice = matched.price;
      }
    }

    const lineTotal = unitPrice * qty;
    subtotalInr += lineTotal;
    lines.push({
      productId: product.id,
      title: product.title,
      size,
      color: item.color ? String(item.color).trim().slice(0, 40) : undefined,
      printSummary,
      unitPrice,
      quantity: qty,
      lineTotal,
    });
  }

  const shippingInr = subtotalInr >= FREE_SHIPPING_THRESHOLD ? 0 : FLAT_SHIPPING_INR;
  const grandTotalInr = subtotalInr + shippingInr;
  return { lines, subtotalInr, shippingInr, grandTotalInr };
}

function buildCustomerReceiptText(order: StoredOrder): string {
  const statusLine =
    order.paymentStatus === 'paid'
      ? `Payment: PAID via Razorpay (${order.razorpayPaymentId})`
      : order.paymentStatus === 'cod_confirmed'
      ? 'Payment: Cash on Delivery (COD)'
      : 'Payment: Confirmed (Preview Mode)';

  const itemsText = order.items
    .map(
      (it, idx) =>
        `${idx + 1}. ${it.title} (${it.size}${it.color ? `, ${it.color}` : ''}${
          it.printSummary ? `, ${it.printSummary}` : ''
        }) × ${it.quantity} = ${formatINR(it.lineTotal)}`
    )
    .join('\n');

  return [
    `Hi ${order.customerName}, your PrintStuff order *#${order.orderId}* is confirmed!`,
    statusLine,
    '',
    'Items:',
    itemsText,
    '',
    `Shipping: ${order.shippingInr === 0 ? 'FREE' : formatINR(order.shippingInr)}`,
    `Total Amount: ${formatINR(order.grandTotalInr)}`,
    `Delivery To: ${order.addressLine}`,
    '',
    'Thank you for shopping with PrintStuff!',
  ].join('\n');
}

async function dispatchAutomatedCustomerNotification(
  order: StoredOrder,
  messageText: string
): Promise<{ apiSent: boolean; provider: string; detail: string }> {
  const toPhone = order.customerPhoneE164;
  const preferredChannel = order.notifyChannel;

  // 1. Meta WhatsApp Cloud API (official endpoint)
  const waPhoneId = process.env.WHATSAPP_PHONE_NUMBER_ID?.trim();
  const waToken = process.env.WHATSAPP_ACCESS_TOKEN?.trim();
  if (preferredChannel === 'whatsapp' && waPhoneId && waToken) {
    try {
      const resp = await fetch(
        `https://graph.facebook.com/v20.0/${encodeURIComponent(waPhoneId)}/messages`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${waToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            messaging_product: 'whatsapp',
            to: toPhone.replace(/^\+/, ''),
            type: 'text',
            text: { body: messageText },
          }),
        }
      );
      if (resp.ok) {
        return {
          apiSent: true,
          provider: 'Meta WhatsApp Cloud API',
          detail: `WhatsApp confirmation automatically sent to ${toPhone}.`,
        };
      }
      const errBody = await resp.text();
      console.error('WhatsApp Cloud API error:', resp.status, errBody);
    } catch (err) {
      console.error('WhatsApp Cloud API request failed:', err);
    }
  }

  // 2. Twilio WhatsApp or SMS REST API (official endpoint)
  const twSid = process.env.TWILIO_ACCOUNT_SID?.trim();
  const twAuth = process.env.TWILIO_AUTH_TOKEN?.trim();
  const twWaFrom = process.env.TWILIO_WHATSAPP_FROM?.trim();
  const twSmsFrom = process.env.TWILIO_SMS_FROM?.trim();

  if (twSid && twAuth) {
    const useWa = preferredChannel === 'whatsapp' && Boolean(twWaFrom);
    const fromVal = useWa ? `whatsapp:${twWaFrom!.replace(/^whatsapp:/, '')}` : twSmsFrom;
    const toVal = useWa ? `whatsapp:${toPhone}` : toPhone;

    if (fromVal) {
      try {
        const params = new URLSearchParams({
          To: toVal,
          From: fromVal,
          Body: messageText,
        });
        const authHeader = Buffer.from(`${twSid}:${twAuth}`).toString('base64');
        const resp = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(twSid)}/Messages.json`,
          {
            method: 'POST',
            headers: {
              Authorization: `Basic ${authHeader}`,
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params.toString(),
          }
        );
        if (resp.ok) {
          return {
            apiSent: true,
            provider: useWa ? 'Twilio WhatsApp' : 'Twilio SMS',
            detail: `${useWa ? 'WhatsApp' : 'SMS'} confirmation automatically sent to ${toPhone}.`,
          };
        }
        const errBody = await resp.text();
        console.error('Twilio API error:', resp.status, errBody);
      } catch (err) {
        console.error('Twilio API request failed:', err);
      }
    }
  }

  return {
    apiSent: false,
    provider: 'direct-link',
    detail: `Ready to deliver to ${toPhone} via 1-tap WhatsApp or SMS below.`,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '100kb' }));

  // Public gateway configuration status (never exposes secret keys)
  app.get('/api/orders/config', (_req: Request, res: Response) => {
    const keyId = process.env.RAZORPAY_KEY_ID?.trim() || '';
    const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim() || '';
    const smsConfigured = Boolean(
      process.env.TWILIO_ACCOUNT_SID?.trim() &&
        process.env.TWILIO_AUTH_TOKEN?.trim() &&
        process.env.TWILIO_SMS_FROM?.trim()
    );
    const whatsappApiConfigured = Boolean(
      (process.env.WHATSAPP_PHONE_NUMBER_ID?.trim() &&
        process.env.WHATSAPP_ACCESS_TOKEN?.trim()) ||
        (process.env.TWILIO_ACCOUNT_SID?.trim() &&
          process.env.TWILIO_AUTH_TOKEN?.trim() &&
          process.env.TWILIO_WHATSAPP_FROM?.trim())
    );

    res.json({
      razorpayConfigured: Boolean(keyId && keySecret),
      razorpayKeyId: keyId && keySecret ? keyId : '',
      smsConfigured,
      whatsappApiConfigured,
      storeWhatsappNumber: STORE_WHATSAPP_NUMBER,
    });
  });

  // Step 1 of Razorpay checkout: compute authoritative total & create Razorpay order
  app.post('/api/orders/create-razorpay-order', async (req: Request, res: Response) => {
    const computed = computeCanonicalOrder(req.body?.items);
    if (!computed) {
      res.status(400).json({ error: 'Invalid cart items provided.' });
      return;
    }

    const keyId = process.env.RAZORPAY_KEY_ID?.trim() || '';
    const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim() || '';
    const receiptRef = `PS-${Math.floor(100000 + Math.random() * 900000)}`;

    if (!keyId || !keySecret) {
      res.json({
        mode: 'preview',
        receiptRef,
        subtotalInr: computed.subtotalInr,
        shippingInr: computed.shippingInr,
        grandTotalInr: computed.grandTotalInr,
      });
      return;
    }

    try {
      const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
      const rzpResp = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: computed.grandTotalInr * 100,
          currency: 'INR',
          receipt: receiptRef,
          notes: {
            store: 'PrintStuff',
            itemCount: String(computed.lines.length),
          },
        }),
      });

      const rzpJson = (await rzpResp.json()) as {
        id?: string;
        amount?: number;
        currency?: string;
        error?: { description?: string };
      };

      if (!rzpResp.ok || !rzpJson.id) {
        res.status(502).json({
          error: rzpJson?.error?.description || 'Failed to create Razorpay order.',
        });
        return;
      }

      pendingRazorpayOrders.set(rzpJson.id, {
        grandTotalInr: computed.grandTotalInr,
        createdAt: Date.now(),
      });

      res.json({
        mode: 'live',
        razorpayKeyId: keyId,
        razorpayOrderId: rzpJson.id,
        amountPaise: rzpJson.amount,
        currency: rzpJson.currency || 'INR',
        receiptRef,
        subtotalInr: computed.subtotalInr,
        shippingInr: computed.shippingInr,
        grandTotalInr: computed.grandTotalInr,
      });
    } catch (err) {
      console.error('Razorpay order creation failed:', err);
      res.status(502).json({ error: 'Unable to reach Razorpay gateway right now.' });
    }
  });

  // Step 2: Verify Razorpay HMAC signature (or confirm COD) & send customer message
  app.post('/api/orders/verify-and-notify', async (req: Request, res: Response) => {
    const computed = computeCanonicalOrder(req.body?.items);
    if (!computed) {
      res.status(400).json({ error: 'Invalid order items.' });
      return;
    }

    const customer = req.body?.customer || {};
    const name = String(customer.name || '').trim().slice(0, 80);
    const city = String(customer.city || '').trim().slice(0, 60);
    const address = String(customer.address || '').trim().slice(0, 200);
    const postalCode = String(customer.postalCode || '').trim().slice(0, 12);
    const phoneE164 = normalizeIndianPhoneE164(String(customer.phone || ''));
    const notifyChannel: 'whatsapp' | 'sms' =
      customer.notifyChannel === 'sms' ? 'sms' : 'whatsapp';

    if (!name || !city || !address || !postalCode || !phoneE164) {
      res.status(400).json({
        error: 'Please enter a valid name, 10-digit mobile number, address, city, and PIN code.',
      });
      return;
    }

    const paymentMethod: 'razorpay' | 'cod' =
      req.body?.paymentMethod === 'cod' ? 'cod' : 'razorpay';
    const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim() || '';

    let paymentStatus: StoredOrder['paymentStatus'] = 'cod_confirmed';
    let razorpayOrderId: string | undefined;
    let razorpayPaymentId: string | undefined;

    if (paymentMethod === 'razorpay') {
      const rzpOrderId = String(req.body?.razorpay_order_id || '').trim();
      const rzpPaymentId = String(req.body?.razorpay_payment_id || '').trim();
      const rzpSignature = String(req.body?.razorpay_signature || '').trim();

      if (keySecret) {
        if (!rzpOrderId || !rzpPaymentId || !rzpSignature) {
          res.status(400).json({ error: 'Missing Razorpay payment signature fields.' });
          return;
        }
        const pending = pendingRazorpayOrders.get(rzpOrderId);
        if (!pending || pending.grandTotalInr !== computed.grandTotalInr) {
          res.status(400).json({ error: 'Order amount verification mismatch.' });
          return;
        }

        const expectedSig = crypto
          .createHmac('sha256', keySecret)
          .update(`${rzpOrderId}|${rzpPaymentId}`)
          .digest('hex');

        const expectedBuf = Buffer.from(expectedSig, 'utf8');
        const actualBuf = Buffer.from(rzpSignature, 'utf8');
        if (
          expectedBuf.length !== actualBuf.length ||
          !crypto.timingSafeEqual(expectedBuf, actualBuf)
        ) {
          res.status(400).json({ error: 'Razorpay payment signature verification failed.' });
          return;
        }

        pendingRazorpayOrders.delete(rzpOrderId);
        paymentStatus = 'paid';
        razorpayOrderId = rzpOrderId;
        razorpayPaymentId = rzpPaymentId;
      } else {
        paymentStatus = 'preview_verified';
      }
    }

    const orderId = `PS-${Math.floor(10000 + Math.random() * 90000)}`;
    const storedOrder: StoredOrder = {
      orderId,
      createdAt: new Date().toISOString(),
      paymentMethod,
      paymentStatus,
      razorpayOrderId,
      razorpayPaymentId,
      customerName: name,
      customerPhoneE164: phoneE164,
      notifyChannel,
      addressLine: `${address}, ${city} - ${postalCode}`,
      items: computed.lines,
      subtotalInr: computed.subtotalInr,
      shippingInr: computed.shippingInr,
      grandTotalInr: computed.grandTotalInr,
    };

    completedOrders.set(orderId, storedOrder);
    const receiptText = buildCustomerReceiptText(storedOrder);
    const notifyResult = await dispatchAutomatedCustomerNotification(
      storedOrder,
      receiptText
    );

    res.json({
      verified: true,
      order: storedOrder,
      receiptText,
      notification: notifyResult,
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PrintStuff storefront running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
